/************************************
*          LED Clock V1             *
*          21 July 2017             *
************************************/
/*
lasted edit: 30-Jul-2017
use MCC to configure:
TMR0
TMT1
CRC
write code for delay_XXXus();

find code to implement these functions
void bitSet(byte n,byte m);
void bitClear(byte n,byte m);
byte bitRead(byte n, byte m);
void bitWrite(byte n, byte m, byte o);

work on the follwoing items:
1) clean up main loop, get to compile $done
2) display
3) RTC and test code
4) TEMT440 and test code
5) DS18B20 and test code
6) main loop

Name: LED clock ver 1
Description:
This project is a simple electronic alarm clcok with four digit LED display.
The clock has the following features:
Temperature
Ambient light sensor for brightness control
Silent flashing alarm,
RTC and battery backup
Powered by USB
Night time readable red LED display
Audible alarm
See blog post for detailed writeup.
Processor: PIC16F18855
Sensors: 
Temperature: DS18B20
Ambient light: TEMT440
Requires:
Hardware configuration: PIC16F18855
MCU configuration
clock settings
peripherals
TMR0: used to generate 1ms tick  <-- need to fix this, 100 ms or 1ms???
TMR1: used for LED refresh and duty cycle
NCO: used to generate 2kHz square wave for buzzer
ADC: used to read the TEMT4400 ambient light sensor
need to look at thermostat code and PT code to get configuration settings

MCU Pin: function and connections
1: Vpp/MCLR/RE3: ICSP 1
2: RA0: D4
3: RA1: DP
4: RA2: G_seg
5: RA3: F_seg
6: RA4: E_seg
7: RA5: D_seg
8: Vss: ground
9: RA7: C_seg
10: RA6: B_seg
11: RC0: A_seg
12: RC1: D2
13: RC2: D3
14: RC3: D1

15: RC4: SW1
16: RC5: SW2
17: RC6: AMB_LT, ambient light sensor, TEMT4400
18: RC7: NCO, buzzer
19: Vss: ground
20: Vdd: +5VDC
21: RB0: NC
22: RB1: SQW
23: RB2: SCL, i2c lines controlled by bit banging the SDA and SCL lines
24: RB3: SDA
25: RB4: Temp_sensor, DS18B20
26: RB5: LED
27: RB6: ICSPCLK: ICSP 5
28: RB7: ICSPDAT: ICSP 4 

Author: Tony Cirineo
Date: 7/21/2017 coding started
Code for the peripherals was generated using MPLAB Code Configurator.
Application code is all in main.c

Revision History

*/

#include "mcc.h"
//#include "mcc_generated_files/mcc.h"
#include <math.h>
#include <stdlib.h>

//defines
#define LOW 0
#define HIGH 1
#define TRUE 1
#define FALSE 0
typedef unsigned char byte;
typedef unsigned int word;
#define DS1307_ADDRESS 0x68
#define BUZZER  NCO1CONbits.N1EN
#define buzzer_on()    NCO1CONbits.N1EN = 1
#define buzzer_off()    NCO1CONbits.N1EN = 0

// function declarations
byte decToBcd(byte val);
byte bcdToDec(byte val);

void set_time_date(void);
void set_time_date(void);
void set_alarm(void);
void dsply_temp(void);
void dsply_alarm(void);
void cycle_alarm(void);
void reset_alarm(void);

void set_RTC(void);
void read_RTC(void);
void write_ds1307(byte wdr_addrs, byte *ptr, byte len);
void read_ds1307(byte wrd_addrs, byte *ptr, byte len);

byte i2c_read(void);
void i2c_write(byte output_data);
void i2c_stop(void);
void i2c_start(void);
void delay_100us(void);
void delay_10us(void);

void delay_1us(void);
void delay_50us(void);
void delay_60us(void);
void delay_500us(void);
void delay_750us(void);

byte read_TEMT4400(void);
void read_sw1sw2(void);

void read_DS18B20(void);
byte decToBcd(byte val);
void display(byte val);
void display_digit(char count);
void delay_us(void);
byte debounce_sw(byte port);

void DS18B20_reset(void);
void DS18B20_byte_write(byte command);
byte DS18B20_byte_read(void);
void DS18B20_scratch_read(void);

void bitSet(byte n,byte m);
void bitClear(byte n,byte m);
byte bitRead(byte n, byte m);
void bitWrite(byte n, byte m, byte o);

// variables used in the design
byte r_flg, s_flg;  // used to keep track of the phase of the SQW 1Hz signal
byte relay_on_flg;
byte second;
byte minute;
byte hour; 		// 24 hour time
byte weekDay; 	// 1-7 = Sunday - Saturday
byte monthDay;
byte month;
byte year;
byte rtc_config;
byte pData[60]; //actually only 56 bytes in the DS1307 address space

byte alarm_hr, alarm_min, alarm_arm_flg;   // time of alarm variables
byte alarm_min_cnt, alarm_active_flg;
byte sw1_flg, sw2_flg, sw1_last, sw2_last;
byte sw1_tmr, sw2_tmr;

word millis;
byte sec_cnt; 
byte buzzer_flg, LED_flg;

byte light_lvl; //value is 0 to 100 for 0 to 100%

byte dsply_flg, digit_cnt, num;

word temp;  // 0.0 to 199.0 degrees F in binary
float temp_C, temp_F;     //temperature in C or F
byte LSB, MSB, CRC_Error, TH, TL, Config;

/************************************
*              main                 *
************************************/
/*
Name: main
Synopsis: main program loop
Requires: na
Description: calls initalization, runs while(1) loop 
Author: Tony Cirineo
Date:  12/6/2016
Revision History:
*/
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    BUZZER = 0;         // deactive buzzer
    millis = sec_cnt = 0; 
    buzzer_flg = LED_flg = 0;
    alarm_active_flg = 0;

    //code to turn off segments
    D1_SetHigh();
    D2_SetHigh();
    D3_SetHigh();
    D4_SetHigh();
    
    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    //I2C initialization, I2C only interfaces to the RTC
    // set the SDA line low and use TRIS to control the state
    SDA_SetLow();
    SDA_SetDigitalInput();  //SDA is Hi Z

    // set the SCL line as an output
    SCL_SetDigitalOutput();   
    SCL_SetHigh();
    SQW_SetDigitalInput();

    // Create a start condition followed by a stop condition	
	i2c_start();
	i2c_stop();	

    //set_time_date();    //comment out after running once to set the time

    ADCC_Initialize();
    //get ambient light reading
    delay_us();
    light_lvl = read_TEMT4400();  // read ambient light once to start
 
    // read alarm settings from non-volital memory
    alarm_hr = eeprom_read(0x00);
    alarm_min = eeprom_read(0x01);
    alarm_arm_flg = eeprom_read(0x02);


    LED_flg = FALSE;
//    dsply_sp_flg = getting_new_sp_flg = getting_new_sp_tmr = FALSE;
//    dsply_sp_tmr = bypass_tmr = 0;

set_RTC();
set_time_date();
set_alarm();
dsply_temp();
dsply_alarm();
cycle_alarm();   
reset_alarm();
read_DS18B20();

    // add code to check for DST time change sence last power up
    read_RTC();

    while(1){   
        // check for user inputs
        // while reading switch status, still need to run while loop        
        read_sw1sw2(); 

        // check millis and update seconds & minutes
        if(millis > 999){
            sec_cnt++;
            millis = 0; 
            // increment timers
            if(sec_cnt > 59)
                alarm_min_cnt++;
        }     

        /*
        Enter new time and date: Hold SW1 & SW2 for 5 seconds
        Year: display last programed year ie. 2017, use SW1 and SW2 to go up and down, increment or decrement on release.
        Hold down both to set.
        Month: display last programed month, use SW1 and SW2 to go up and down, increment or decrement on release.
        nio (mo) 88 (1 to 12)
        Day: display last programed day, use SW1 and SW2 to go up and down, increment or decrement on release.
        d4 (dy):88 (1 to 31)
        Day of week: display last programed day of week, use SW1 and SW2 to go up and down, increment or decrement on release.
        dow: douu (dow) 8 (1 to 7) with sunday = 1
        Hour:  hr 88 (0 to 23)
        Min: n i (m) 88 (0 to 59)
        Hold SW1 to enter the selection
        at some point implement DST for USA location
        */
        // if SW1 and SW2 for 5 sec
        //switch settings
        if(sw1_flg && sw1_tmr > 5 && sw2_flg && sw2_tmr > 5)
            set_time_date();
        /*
        Set alarm
        Hold SW1 for 5 seconds to set alarm
        Hour: hr 88
        Minutes: ni 88
        on/off: cycle alarm through: on  oFF  LED
        */
        // if SW1 for 5 seconds
        if(sw1_flg && sw1_tmr > 5 && !sw2_flg)    
            set_alarm();

        /*    
        Display temperature:
        Short press on SW1 will display temp for 2 seconds, set units in firmware
        C=xx.xC
        F=xx.xF
        */
        // short press on SW1
        if(sw1_flg && sw1_tmr > 2 && !sw2_flg)    
            dsply_temp();

        /*    
        Alarm status
        Short press on SW2 will display alarm time for 4 seconds, when not enabled display oFF.
        Long press on SW2 will disable the alarm, if enabled
        */
        //short press on SW2
        if(!sw1_flg && sw2_flg && sw2_tmr > 2)
            dsply_alarm();

        // long press on SW2
        if(!sw1_flg && sw2_flg && sw2_tmr > 4)
            cycle_alarm();  //cycle alarm through: on  oFF  LED
    
        //When alarm is active depressing either SW1 or SW2 turns off alarm.
        if((buzzer_flg || LED_flg) && (sw1_flg || sw2_flg)) //check alarm_active_flg
            reset_alarm();


#if 0
// update the four digit display with hours and minutes
use timer 1 to control LED display, referesh time and duty cycle
digit_cnt: 0 to 3, 4=digit off

Chect to see what ADC uses for timer

// initialize these variables
TMR1L & TMR1H
digit_cnt
isr_tgl

TMR1_ISR()
{
    if(isr_tgl){
        //code to turn off segments
        D1_SetHigh();
        D2_SetHigh();
        D3_SetHigh();
        D4_SetHigh();
        // set the off time amount
        TMRL1 = 0xf0;
        TMRH1 = 0xff; 

        isr_tgl = 0
    }
    else{
        dsply_flg = 1;
       // set the on time amount
        TMRL1 = 0xf0;
        TMRH1 = 0xff; 

        isr_tgl++;        
    }   
}

num = decToBcd(minute);  // convert minutes to BCD
num = decToBcd(hour);  // convert hours to BCD

//code to turn off segments
D1_SetHigh();
D2_SetHigh();
D3_SetHigh();
D4_SetHigh();
#endif

        // this code turns on the segments, if timer1 ISR sets the flag
        if(dsply_flg){
            dsply_flg = 0;
        
            if(digit_cnt > 3)
                digit_cnt = 0;
            else
                digit_cnt++;  
        
            switch(digit_cnt){
                case 0://display digit 0
                    num = decToBcd(minute);  // convert minutes to BCD
                    // display ones digit
                    D1_SetLow();
                    display_digit(num & 0x0f); 
                break;
                case 1://display digit 1
                    // display tens digit
                    D2_SetLow();
                    display_digit(num >> 4);            
                break;    
                case 2://display digit 2
                    num = decToBcd(hour);  // convert hours to BCD
                    // display ones digit
                    D3_SetLow();
                    display_digit(num & 0x0f); 
                break;
                case 3://display digit 3
                    // display tens digit
                    D4_SetLow();
                    display_digit(num >> 4);   
                break;
            }
        }

        // check for a new 1Hz rising edge        
        if(SQW_GetValue() && !s_flg)
            r_flg = 1;
        if(!SQW_GetValue() && !r_flg)
            s_flg = 0;

        // check millis and update seconds
        if(r_flg){
            sec_cnt++;
            millis = 0;
//            LED_blue_flg = 1; 
//            LED_blue_SetLow();
            s_flg = 1;
            r_flg = 0;
        }  
        
        // read time and date every 10 seconds
        if(sec_cnt > 9){
            sec_cnt = 0;
            read_RTC();

            // check alarm
            if(alarm_arm_flg && (hour == alarm_hr) && (minute == alarm_min)){
                // check for LED or buzzer
                // activate buzzer
                buzzer_flg = 1;
                buzzer_on();
                // start minute counter to turn off alarm after 5 min
                alarm_min_cnt = 0;
                alarm_active_flg;
            }
   
        }

        // control LED
        if((millis > 25) && LED_flg){
//            LED_SetHigh();
//            LED_flg = 0; 
        }

        // control buzzer
        if((millis > 100) && (millis <= 199) && buzzer_flg){
            buzzer_off();
        }
         if((millis > 200) && (millis <= 299) && buzzer_flg){
            buzzer_on();
        }       
        if((millis > 300) && (millis <= 399) && buzzer_flg){
            buzzer_off();
        } 
        if((millis > 400) && (millis <= 499) && buzzer_flg){
            buzzer_on();
        } 
        if((millis > 500) && buzzer_flg){
            buzzer_off();
            buzzer_flg = 0;
        }       
    }
}

// these still need work
void set_time_date(void){}
void set_alarm(void){
    eeprom_write(0x00, alarm_hr);
    eeprom_write(0x01, alarm_min);
    eeprom_write(0x02, alarm_arm_flg); 
}
void dsply_temp(void){}
void dsply_alarm(void){}
void cycle_alarm(void){}   
void reset_alarm(void){}
            
            
/************************************
*         read_TEMT4400             *
************************************/
/*
Name: read_TEMT4400
Synopsis: returns ambient light level, 0 to 100% scaled as 0 to 100
Requires: TEPT4400, 10K emitter resistor
Description: TEPT4400 ambient light sensor is a silicon NPN epitaxial
planar phototransistor in a T-1 package. It is sensitive to
visible light much like the human eye and has peak
sensitivity at 570 nm.
Data sheet specs.:
Collector current at Vce = 5 V, from figure 5
Ev = 10 lx, 20 ?A
Ev = 1000 lx, 2000?A
Angle of half sensitivity ? - � 30 - deg
Wavelength of peak sensitivity ?p - 570 - nm
Range of spectral bandwidth ?0.5 - 440 to 800 - nm
Collector emitter saturation voltage
Ev = 20 lx, CIE illuminant A, Ipce = 1.2 ?A, 0.1V typical

Author: Tony Cirineo
Date:  27 July 2017
Revision History:

*/
byte read_TEMT4400(void)
{
unsigned int k;

    k = ADCC_GetSingleConversion(AMB_LT);       
	// 0.1 Vce sat volts, 5-0.1= 4.9 -> ~656 counts full scale <- need to check this
	k *= 100;
	k /= 656;	    //percent of full scale	
	return((byte) k);   // return 0 to 100
}

/************************************
*         read_DS18B20              *
************************************/
/*
Name: read_DS18B20
Synopsis: Reads the DS18B20 temperature sensor and 
returns degrees F value as 8 bits, 0.0 to 199.0F.
Requires: DS18B20
Description: 
Uses MCU pin to read the 1 wire interface of the 
DS18B20 and converts the value to degrees F.  
The value returned is a 8 bits, 0 to 199F.
The DS18B20 digital thermometer provides 9-bit to 12-bit
Celsius temperature measurements and has an alarm
function with nonvolatile user-programmable upper and
lower trigger points. The DS18B20 communicates over a
1-Wire bus that by definition requires only one data line
(and ground) for communication.
Temperature range 
-55�C to +125�C
(-67�F to +257�F)
Temperature accuracy 
-10�C to +85�C: �0.5�C maximum
-55�C to +125�C: �2�C maximum
Programmable Resolution from 9 Bits to 12 Bits
Supply voltage: 3 to 5.5VDC
Storage Temperature: -55�C to +125�C
Ambient Temp. with Power Applied: -40�C to +150�C
Manufacturer: Maxim Integrated Products, Inc.
Part Number: DS18B20, TO-92 package
Author: Tony Cirineo
Date:  12/6/2016
Revision History:
*/
void read_DS18B20(void){
int i;

    LSB = 0;
    MSB = 0;
    temp_C = 0;
    DS18B20_reset();

    DS18B20_byte_write(0xCC);  //skip the ROM command
    DS18B20_byte_write(0x44);  //convert the temp command
    delay_750us();  //delay to allow conversion to complete
    DS18B20_reset();  //reset
    DS18B20_byte_write(0xCC); //skip ROM command
    DS18B20_scratch_read(); //read scratch pad, which includes the temp
}

/************************************
*      Read SW1 and SW2             *
************************************/
/*
Name: read_sw1sw2
Synopsis: Reads switch status on DIO ports and manages switch related timers.
Requires: SW1 and SW2
Description: 
typical call:
if(sw1_flg && sw1_tmr > 5 && sw2_flg && sw2_tmr > 5)
RC4: SW1
RC5: SW2
Author: Tony Cirineo
Date:  7/28/2017
Revision History:
*/
void read_sw1sw2(void)
{
    sw1_flg = debounce_sw(PORTCbits.RC4);
    if(!sw1_last && sw1_flg)    // need to check the logic
        sw1_tmr = 0;    // start sw1 timer

    sw2_flg = debounce_sw(PORTCbits.RC5);
    if(!sw2_last && sw2_flg)
        sw2_tmr = 0;    // start sw1 timer

    sw1_last = sw1_flg;
    sw2_last = sw2_flg;
}

/************************************
*           debounce_sw             *
************************************/
/*
Name: debounce_sw
Synopsis: debounce switch input
Requires: na
Description: Delay used to allow data lines
to stabilize from the key fill device.
Author: Tony Cirineo
Date:  
Revision History:

*/
byte debounce_sw(byte port)
{
byte sp1, sp2;
    do{
        sp1 = port;
        delay_us();
        sp2 = port;
    } while(sp1 != sp2);
    return(sp1);
}

/************************************
*            display_digit          *
************************************/
/*
Name: display_digit
Synopsis: controls the segments to display a number
Requires: na
Description:

add other characters
n, o, h, r, i, F
need to make count an int to add more characters
left 1, -, top -, bottom -
all_seg_off as a character

change variable count to symbol or something, sym?

Author: Tony Cirineo
Date:  5/16/2017
Revision History:
*/
void display_digit(char count)
{
    switch(count){
        case 0://when count value is zero show"0" on disp
            A_seg_SetHigh();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetHigh();
            E_seg_SetHigh();
            F_seg_SetHigh();
            G_seg_SetLow();
            break;
        case 1:// when count value is 1 show"1" on disp
            A_seg_SetLow();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetLow();
            E_seg_SetLow();
            F_seg_SetLow();
            G_seg_SetLow();
            break;
        case 2:// when count value is 2 show"2" on disp
            A_seg_SetHigh();
            B_seg_SetHigh();
            C_seg_SetLow();
            D_seg_SetHigh();
            E_seg_SetHigh();
            F_seg_SetLow();
            G_seg_SetHigh();
            break;
        case 3:// when count value is 3 show"3" on disp
            A_seg_SetHigh();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetHigh();
            E_seg_SetLow();
            F_seg_SetLow();
            G_seg_SetHigh();
            break;
        case 4:// when count value is 4 show"4" on disp
            A_seg_SetLow();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetLow();
            E_seg_SetLow();
            F_seg_SetHigh();
            G_seg_SetHigh();
            break;
        case 5:// when count value is 5 show"5" on disp
            A_seg_SetHigh();
            B_seg_SetLow();
            C_seg_SetHigh();
            D_seg_SetHigh();
            E_seg_SetLow();
            F_seg_SetHigh();
            G_seg_SetHigh();
            break;
        case 6:// when count value is 6 show"6" on disp
            A_seg_SetHigh();
            B_seg_SetLow();
            C_seg_SetHigh();
            D_seg_SetHigh();
            E_seg_SetHigh();
            F_seg_SetHigh();
            G_seg_SetHigh();
            break;
        case 7:// when count value is 7 show"7" on disp
            A_seg_SetHigh();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetLow();
            E_seg_SetLow();
            F_seg_SetLow();
            G_seg_SetLow();
            break;
        case 8:// when count value is 8 show"8" on disp
            A_seg_SetHigh();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetHigh();
            E_seg_SetHigh();
            F_seg_SetHigh();
            G_seg_SetHigh();
            break;
        case 9:// when count value is 9 show"9" on disp
            A_seg_SetHigh();
            B_seg_SetHigh();
            C_seg_SetHigh();
            D_seg_SetHigh();
            E_seg_SetLow();
            F_seg_SetHigh();
            G_seg_SetHigh();
            break;
    }  
} 

/************************************
*            read RTC               *
************************************/
/*
Name: read RTC
Synopsis:
Requires: na
Description:
Author: Tony Cirineo
Date:
Revision History:

*/
void read_RTC(void)
{
byte dev_addrs;
byte i;

  read_ds1307(0, pData, 8);

  second = bcdToDec(pData[0]);
  minute = bcdToDec(pData[1]);
  hour = bcdToDec(pData[2] & 0b111111); //24 hour time
  weekDay = bcdToDec(pData[3]); //1-7 -> Sunday - Saturday
  monthDay = bcdToDec(pData[4]);
  month = bcdToDec(pData[5]);
  year = bcdToDec(pData[6]);
  rtc_config = pData[7];
}

/************************************
*           set RTC                 *
************************************/
/*
Name: set RTC
Synopsis:
Requires: na
Description:
Author: Tony Cirineo
Date:
Revision History:

*/
void set_RTC(void)
{
byte dev_addrs;
byte i;

    // put formated data into array for sending
    // set values for clock
    second =      0; //0-59, this also sets the CH bit to zero = osc runs
    minute =      10; //0-59
    hour =        13; //0-23
    weekDay =     7; //1-7
    monthDay =    8; //1-31
    month =       7; //1-12
    year  =       17; //0-99
    rtc_config = 0x10; //turn on SQW 1Hz    
    
    pData[0] = decToBcd(second);
    pData[1] = decToBcd(minute);
    pData[2] = decToBcd(hour);
    pData[3] = decToBcd(weekDay);
    pData[4] = decToBcd(monthDay);
    pData[5] = decToBcd(month);
    pData[6] = decToBcd(year);
    pData[7] = rtc_config;    
    
    write_ds1307(0, pData, 8);
}

/************************************
*      Dec & BCD Conversions        *
************************************/
/*
Name: 
Synopsis: 
Requires:
Description: 
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
byte decToBcd(byte val){
// Convert normal decimal numbers to binary coded decimal
  return ( (val/10*16) + (val%10) );
}

byte bcdToDec(byte val)  {
// Convert binary coded decimal to normal decimal numbers
  return ( (val/16*10) + (val%16) );
}

/************************************
*       write ds1307                *
************************************/
/*
Name: write ds1307
Synopsis: writes data to the DS1307 real time clock
Requires: 
wrd_addrs:  word address or register pointer 
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void write_ds1307(byte wrd_addrs, byte *ptr, byte len)
{
byte dev_addrs;
byte i;

	// build device address
	dev_addrs = DS1307_ADDRESS << 1;    // leave R/W bit as a zero

	// write device address, word address, then len bytes of data
	i2c_start();
	i2c_write(dev_addrs);	// device address
	i2c_write(wrd_addrs);	// word address
	for(i = 0;i < len;i++)
		i2c_write(*ptr++);
	i2c_stop();	// create a stop condition
}

/************************************
*       read ds1307                 *
************************************/
/*
Name: data read ds1307
Synopsis: 
Data Read (Write Pointer, Then Read)-Slave Receive and Transmit

Requires: 
wrd_addrs:  word address or register pointer 
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void read_ds1307(byte wdr_addrs, byte *ptr, byte len)
{
byte dev_addrs;
byte i,j,input_data;

	// write device address, then word address followed by repeated start
	dev_addrs = DS1307_ADDRESS << 1;    //leave w/r set to 0
	i2c_start();
	i2c_write(dev_addrs);	// device address
	i2c_write(wdr_addrs);	// word address
	i2c_start();	// send start condition

    // read the data from the device
	dev_addrs |= 0x01;      //set the w/r bit to 1 for read
	i2c_write(dev_addrs);	// device address   

    // read len-1 bytes of data followed by ACK
    SDA_SetDigitalInput();        	// set SDA pin as input
    delay_10us();
    for(i = 0;i < len-1;i++){
        input_data = 0x00;
        for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
            input_data <<= 1;   // Shift the byte by one bit
            SCL_SetHigh();         // Clock the data into the I2C Bus
            delay_10us();
            input_data |= SDA_GetValue();  // Input the data from the I2C Bus
            delay_10us();
            SCL_SetLow();
            delay_10us();
        }
        // send ACK
        SDA_SetLow();    	// send ACK valid
        SDA_SetDigitalOutput();   // Put port pin to output   
        delay_10us();
        SCL_SetHigh();		// Clock the ACK from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
        SDA_SetDigitalInput(); //return SDA to Hi Z	
        *ptr++ = input_data;        //save received data
    }
    
    // now read last byte of data followed by NACK
    input_data = 0x00;
    for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // send NACK
    SDA_SetHigh();    	// send NACK valid
    SDA_SetDigitalOutput();   // Put port pin to output   
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z	  
    
    *ptr = input_data;        //save last received data    

	i2c_stop();	// create a stop condition
}

/************************************
*           delay_???us             *
************************************/
/*
Name: delay_???us
Synopsis: various fixed delays
Requires: na
Description: Delay used to allow data lines
to stabilize from the key fill device.
count vs delay
_nop(); 10us
1       20  us
14		100 us
Author: Tony Cirineo
Date:  
Revision History:
*/
void delay_10us(void)
{
    _nop();
}
void delay_100us(void)
{
word i;
    for(i = 0;i < 14;i++);	// loop for a small delay, 100 us
}


void delay_1us(void){}
void delay_50us(void){}
void delay_60us(void){}
void delay_500us(void){}
void delay_750us(void){}


/************************************
*           delay_us                *
************************************/
/*
Name: delay_us
Synopsis: various fixed delays
Requires: na
Description: Delay used to allow data lines
to stabilize from the key fill device.
Author: Tony Cirineo
Date:  
Revision History:

*/
void delay_us(void)
{
word i;
	for(i = 0;i < 100;i++);	// loop for a small delay
}

/************************************
*            i2c_start              *
************************************/
/*
Name: i2c_start
Synopsis: Sends I2C start condition.
Requires: na
Description: This function toggles the scl and sda
lines initiate the start condition
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
5/5/2015: updated
*/
void i2c_start(void)
{
    //SDA_SetHigh();     // Set data line high
    SDA_SetDigitalInput(); // let the pull up control the line
    delay_10us();
    SCL_SetHigh();     // Set clock line high
	delay_10us();
    //SDA_SetLow();      // Set data line low (START SIGNAL)
    SDA_SetDigitalOutput();
	delay_10us();
    SCL_SetLow();      // Set clock line low
	delay_10us();
}

/************************************
*            i2c_stop               *
************************************/
/*
Name: i2c_stop
Synopsis: Sends I2C Stop condition
Requires: na
Description: This function toggles the scl and sda
lines initiate the stop condition
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
5/5/2015: updated
*/
void i2c_stop(void)
{
byte input_var;

    SCL_SetLow();          // Set clock line low
    delay_10us();
    SDA_SetLow();          // Set data line low
    SDA_SetDigitalOutput(); // set SDA to output
	delay_10us();
    SCL_SetHigh();         // Set clock line high
	delay_10us();
    SDA_SetDigitalInput(); //release the line
	delay_10us();
}

/************************************
*            i2c_write              *
************************************/
/*
Name: i2c_write
Synopsis: Writes data over the I2C bus
Requires: na
Description: This function toggles the scl and sda
lines to write a byte of data. Clocks acknowledge (ACK)
but ignores it.  
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
*/
void i2c_write(byte output_data)
{
byte i;
    SDA_SetHigh();      //SDA line is normally pulled high
    SDA_SetDigitalOutput();  //set as output
    delay_10us();
    for(i = 0; i < 8; i++){	// Send 8 bits to the I2C Bus
        // Output the data bit to the I2C Bus
        SDA_LAT = ((output_data & 0x80) ? 1 : 0);
        delay_10us();
        output_data  <<= 1; // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
		delay_10us();
        SCL_SetLow();
        delay_10us();
    }
	// get the ACK & ignore
    SDA_SetDigitalInput();  	// release pin (open drain output)
	delay_10us();
    SCL_SetHigh();     // Clock the ACK from the I2C Bus
	delay_10us();
    SCL_SetLow();
	delay_10us();
    SDA_SetLow();   // leave SDA LAT as low and Hi Z
}

/************************************
*       DS18B20_byte_write         *
************************************/
/*
Name: DS18B20_byte_write
Synopsis: writes a command to the DS18B20 pin
Requires: na
Description: Delay used to allow data lines
to stabilize from the key fill device.
Author: Tony Cirineo
Date:
Revision History:
*/
void DS18B20_byte_write(byte command){
int i;

    for(i = 0; i < 8;i++){
        if(bitRead(command, i)){  //if bit is a '1'
            Temp_sensor_SetDigitalOutput();    //set pin as output
            Temp_sensor_SetLow();
            delay_1us();
            Temp_sensor_SetDigitalInput();  //allows pin to be pulled up
            delay_60us();
        }
        else{   //bit is a '0'
            Temp_sensor_SetDigitalOutput();
            Temp_sensor_SetLow();
            delay_60us();
            Temp_sensor_SetDigitalInput();
            delay_1us();
        }
    }
}

/************************************
*         DS18B20_byte_read         *
************************************/
/*
Name: DS18B20_byte_read
Synopsis: reads a byte from the DS18B20
Requires: na
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
byte DS18B20_byte_read(void){
byte i;
byte byte_in = 0;
  
    for(i = 0; i < 8;i++){
        Temp_sensor_SetDigitalOutput();
        Temp_sensor_SetLow();
        delay_1us();  //used to have a delay of 1us here, turned out it was giving corrupt data
        Temp_sensor_SetDigitalInput();
        delay_10us();

        //if pulled low, then we read in a '0', if high, then the bit is a '1'
        if(Temp_sensor_GetValue())  //grab the line status
            bitSet(byte_in,i);//set it or
        else
            bitClear(byte_in,i);//clear it
        delay_50us();   //Microseconds(49); //wait out the rest of the timing window
    }
    return(byte_in);
}


/************************************
*          DS18B20_reset            *
************************************/
/*
Name: DS18B20_reset
Synopsis: set the data pint low for 500us, then releases the line
Requires: na
Description:

Author: Tony Cirineo
Date:
Revision History:
*/
void DS18B20_reset(void){

    Temp_sensor_SetDigitalInput();
    Temp_sensor_SetLow();
    delay_500us();
    Temp_sensor_SetDigitalInput();
    delay_500us();
}


/************************************
*         DS18B20_scratch_read      *
************************************/
/*
Name: DS18B20_scratch_read
Synopsis:
Requires: na
Description:

Read Scratchpad [BEh]
This command allows the master to read the contents of
the scratchpad. The data transfer starts with the least significant
bit of byte 0 and continues through the scratchpad
until the 9th byte (byte 8 - CRC) is read. The master may
issue a reset to terminate reading at any time if only part
of the scratchpad data is needed.

BYTE 0: TEMPERATURE LSB (50h)
BYTE 1: TEMPERATURE MSB (05h) (85�C)
BYTE 2: TH REGISTER OR USER BYTE 1*
BYTE 3: TL REGISTER OR USER BYTE 2*
BYTE 4: CONFIGURATION REGISTER*
BYTE 5: RESERVED (FFh)
BYTE 6: RESERVED
BYTE 7: RESERVED (10h)
BYTE 8 CRC*
*POWER-UP 

Configuration Register
Byte 4 of the scratchpad memory contains the configuration
register, which is organized as illustrated in Figure 10.
The user can set the conversion resolution of the DS18B20
using the R0 and R1 bits in this register as shown in Table
2. The power-up default of these bits is R0 = 1 and R1 =
1 (12-bit resolution). Note that there is a direct tradeoff
between resolution and conversion time. Bit 7 and bits 0 to
4 in the configuration register are reserved for internal use
by the device and cannot be overwritten.

Author: Tony Cirineo
Date:
Revision History:
*/
void DS18B20_scratch_read(void){
byte i, j;
byte data_in[9], CRC = 0;
byte CRCxor;   // was boolean CRCxor;
temp_C = 0;
  
  //things are about to get a little crazy here
  //this is where the scratchpad is read out and checked against the CRC
  //the LSB MSB of the temperature is converted into a float value
  
  
    DS18B20_byte_write(0xBE); //read scratch
    for(i=0; i<9; i++){   // read 9 bytes
        data_in[i] = DS18B20_byte_read(); //keep it all in data_in[0..8]
    }
  
    for(i = 0;i < 8;i++){     //CRC checker, 8 bytes wide, 9th byte is the CRC
        for(j = 0;j < 8;j++){
            CRCxor = bitRead(data_in[i], j) ^ bitRead(CRC, 0);  //XOR CRC bit 0 with the incoming bit
            bitWrite(CRC, 3, (CRCxor^bitRead(CRC, 3))); //take that XOR result and XOR it with the 3rd bit in the CRC
            bitWrite(CRC, 4, (CRCxor^bitRead(CRC, 4))); //do the same with the 4th bit
            CRC = CRC>>1;   //shift the whole CRC byte over to the right once
            bitWrite(CRC, 7, CRCxor);   //now store the XOR bit into the last position of the CRC byte
        } 
    }
    //Serial.println(CRC, HEX);//print stuff if you want to see the results
    //Serial.println(data_in[8], HEX);
    if(CRC==data_in[8]){    //okay, now check the CRC you made with the 9th byte that came in
        //if we're good, go ahead and set everybody up
        LSB = data_in[0];
        MSB = data_in[1];
        TH = data_in[2];
        TL = data_in[3];
        Config = data_in[4];
        CRC_Error = 0;
    }
    else{    //if not, set everybody to 0
        CRC_Error = 1;//ALSO - set a flag, you can use this to see if there was a fail
        LSB = 0;
        MSB = 0;
        TH = 0;
        TL = 0;
        Config = 0;
    }

    if(bitRead(MSB, 7)==0){//check to see if the temp is negative
        //positive temperature
      
        for(i = 0;i < 4;i++){   //first set the fractional part of the number
            if(bitRead(LSB,i) == 0) //only the bottom 4 bits represent 0.5, 0.25, 0.125, 0.0625
                temp_C = temp_C+pow(2.0, -4.0+i);//yes, this is weird, but it makes sense,
                // 2^-1 = 0.5, 2^-2=0.25, 2^-3=0.125, and 2^-4=0.0625
        }

        //tempC is the fractional part right now, so we add that to the integer part
        //the top 4 of LSB are 2^0, 2^1... so we shift that to the right 4 times to get it lined up
        //then the MSB only contains 3 contributing bits, so we AND off everything else
        //then shift that to the left 4 times to line it up with the LSB we just shifted over
        temp_C = temp_C + (LSB>>4) + ((0b00000111 & MSB)<<4);
        //convert to F, for those of us who can't use Celsius :)
        temp_F = (temp_C)*9.0/5.0+32.0;
    }
    else{
        //or..... if the temp is NEGATIVE
        
        //the negative temp comes in as a 2's comliment number, so we need to convert it back
        
        //I did this kinda weird, but I combined the LSB with MSB into a word, then inverted everything,
        // by using a ^ against 0xFFFF, then added '1'.  This converts back to what we were dealing with
        //if the number was positive
        word full16 = ((((0b00000111 & MSB)<<8) + LSB) ^ 0xFFFF)+1;
        MSB = full16 >> 8;  //but, I already had my code ready to work with MSB and LSB, so I pulled them back out
        LSB = full16 & 0x00FF;
        
        //now we're back to normal, so I pulled the same trick as before
        for(i = 0;i < 4;i++){
            if(bitRead(LSB,i))
            temp_C = temp_C+pow(2.0, -4.0+i);
        }
        
        //and this is the same as before, now with a '-1 multiplier'
        temp_C = (temp_C + (LSB>>4) + ((0b00000111 & MSB)<<4))*-1;
        temp_F = (temp_C)*9.0/5.0+32.0;
    }
}

/************************************
*             *
************************************/
// these functions need code
void bitSet(byte n,byte m){}
void bitClear(byte n,byte m){}
byte bitRead(byte n, byte m){
    return 1;
}
void bitWrite(byte n, byte m, byte o){}

#if 0
#define BITMASK(b) (1 << ((b) % CHAR_BIT))
#define BITSLOT(b) ((b) / CHAR_BIT)
#define BITSET(a, b) ((a)[BITSLOT(b)] |= BITMASK(b))
#define BITCLEAR(a, b) ((a)[BITSLOT(b)] &= ~BITMASK(b))
#define BITTEST(a, b) ((a)[BITSLOT(b)] & BITMASK(b))
#define BITNSLOTS(nb) ((nb + CHAR_BIT - 1) / CHAR_BIT)
#endif

//  End of File
 